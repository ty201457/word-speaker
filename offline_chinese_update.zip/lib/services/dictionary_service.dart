import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import '../models/dictionary_entry.dart';

class DictionaryException implements Exception {
  const DictionaryException(this.message);
  final String message;

  @override
  String toString() => message;
}

class DictionaryService {
  String? _dictionaryText;

  Future<void> _load() async {
    if (_dictionaryText != null) return;
    final parts = await Future.wait([
      for (var index = 0; index < 7; index++)
        rootBundle.load('assets/offline_dictionary.tsv.gz.part$index'),
    ]);
    final bytes = Uint8List(parts.fold<int>(0, (sum, part) => sum + part.lengthInBytes));
    var offset = 0;
    for (final part in parts) {
      final chunk = part.buffer.asUint8List(part.offsetInBytes, part.lengthInBytes);
      bytes.setRange(offset, offset + chunk.length, chunk);
      offset += chunk.length;
    }
    _dictionaryText = utf8.decode(gzip.decode(bytes));
  }

  Future<DictionaryEntry> lookup(String input) async {
    final word = input.trim().toLowerCase();
    if (word.isEmpty) {
      throw const DictionaryException('請先輸入英文單字');
    }
    if (!RegExp(r"^[a-z][a-z'-]*$").hasMatch(word)) {
      throw const DictionaryException('目前只支援單一英文單字');
    }

    await _load();
    final match = RegExp(
      '^${RegExp.escape(word)}\\t([^\\t\\n]+)\\t([^\\n]*)',
      multiLine: true,
    ).firstMatch(_dictionaryText!);
    if (match == null) {
      throw const DictionaryException('離線字庫中找不到這個單字');
    }
    final phonetic = _decodeUnicodeEscapes(match.group(1)!);
    final translation = _decodeUnicodeEscapes(match.group(2)!);
    return DictionaryEntry(
      word: word,
      phonetic: phonetic,
      zhuyin: _toZhuyin(phonetic),
      translation: translation.isEmpty ? null : translation,
    );
  }

  String _decodeUnicodeEscapes(String value) {
    return value.replaceAllMapped(
      RegExp(r'\\u([0-9a-fA-F]{4})'),
      (match) => String.fromCharCode(int.parse(match.group(1)!, radix: 16)),
    );
  }

  String _toZhuyin(String phonetic) {
    const sounds = <String, String>{
      'tʃ': 'ㄑ', 'dʒ': 'ㄐ', 'aʊ': 'ㄠ', 'aɪ': 'ㄞ', 'eɪ': 'ㄟ',
      'oʊ': 'ㄡ', 'ɔɪ': 'ㄛㄧ', 'ɑ': 'ㄚ', 'æ': 'ㄟ', 'ʌ': 'ㄚ',
      'ə': 'ㄜ', 'ɛ': 'ㄝ', 'ɝ': 'ㄦ', 'ɚ': 'ㄦ', 'ɪ': 'ㄧ',
      'i': 'ㄧ', 'ɔ': 'ㄛ', 'ʊ': 'ㄨ', 'u': 'ㄨ', 'b': 'ㄅ',
      'p': 'ㄆ', 'm': 'ㄇ', 'f': 'ㄈ', 'v': 'ㄨ', 'd': 'ㄉ',
      't': 'ㄊ', 'n': 'ㄋ', 'l': 'ㄌ', 'ɡ': 'ㄍ', 'k': 'ㄎ',
      'h': 'ㄏ', 'θ': 'ㄙ', 'ð': 'ㄉ', 's': 'ㄙ', 'z': 'ㄗ',
      'ʃ': 'ㄒ', 'ʒ': 'ㄖ', 'ɹ': 'ㄖ', 'r': 'ㄖ', 'j': 'ㄧ',
      'w': 'ㄨ', 'ŋ': 'ㄥ',
    };
    final source = phonetic.replaceAll(RegExp(r'[/ˈˌ]'), '');
    final result = StringBuffer();
    var index = 0;
    while (index < source.length) {
      var matched = false;
      for (final entry in sounds.entries) {
        if (source.startsWith(entry.key, index)) {
          result.write(entry.value);
          index += entry.key.length;
          matched = true;
          break;
        }
      }
      if (!matched) index++;
    }
    return result.toString();
  }
}
