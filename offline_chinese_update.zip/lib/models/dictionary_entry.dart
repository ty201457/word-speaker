class DictionaryEntry {
  const DictionaryEntry({
    required this.word,
    required this.phonetic,
    required this.zhuyin,
    this.translation,
  });

  final String word;
  final String phonetic;
  final String zhuyin;
  final String? translation;
}
