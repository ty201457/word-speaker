import { dictionary } from 'cmu-pronouncing-dictionary'
import { createReadStream, readdirSync, rmSync, writeFileSync } from 'node:fs'
import { dirname, join } from 'node:path'
import { createRequire } from 'node:module'
import { gzipSync } from 'node:zlib'
import { parse } from 'csv-parse'
import { tify } from 'chinese-conv'

const vowels = new Set([
  'AA', 'AE', 'AH', 'AO', 'AW', 'AY', 'EH', 'ER', 'EY',
  'IH', 'IY', 'OW', 'OY', 'UH', 'UW',
])

const ipa = {
  AA: 'ɑ', AE: 'æ', AH: 'ʌ', AO: 'ɔ', AW: 'aʊ', AY: 'aɪ',
  B: 'b', CH: 'tʃ', D: 'd', DH: 'ð', EH: 'ɛ', ER: 'ɝ', EY: 'eɪ',
  F: 'f', G: 'ɡ', HH: 'h', IH: 'ɪ', IY: 'i', JH: 'dʒ', K: 'k',
  L: 'l', M: 'm', N: 'n', NG: 'ŋ', OW: 'oʊ', OY: 'ɔɪ', P: 'p',
  R: 'ɹ', S: 's', SH: 'ʃ', T: 't', TH: 'θ', UH: 'ʊ', UW: 'u',
  V: 'v', W: 'w', Y: 'j', Z: 'z', ZH: 'ʒ',
}

const legalOnsets = new Set([
  'B', 'CH', 'D', 'DH', 'F', 'G', 'HH', 'JH', 'K', 'L', 'M', 'N',
  'P', 'R', 'S', 'SH', 'T', 'TH', 'V', 'W', 'Y', 'Z', 'ZH',
  'P R', 'T R', 'K R', 'B R', 'D R', 'G R', 'F R', 'TH R', 'SH R',
  'S P', 'S T', 'S K', 'S M', 'S N', 'S L', 'S W',
  'P L', 'K L', 'B L', 'G L', 'F L', 'K W', 'G W', 'T W', 'D W',
  'S P R', 'S T R', 'S K R', 'S P L', 'S K W',
])

function stressStart(tokens, vowelIndex, previousVowelIndex) {
  if (previousVowelIndex < 0) return 0
  const between = tokens.slice(previousVowelIndex + 1, vowelIndex)
    .map((token) => token.replace(/\d/g, ''))
  for (let length = Math.min(3, between.length); length >= 1; length--) {
    const candidate = between.slice(-length).join(' ')
    if (legalOnsets.has(candidate)) return vowelIndex - length
  }
  return vowelIndex
}

function toIpa(pronunciation) {
  const tokens = pronunciation.split(' ')
  const markers = new Map()
  let previousVowelIndex = -1

  for (let index = 0; index < tokens.length; index++) {
    const base = tokens[index].replace(/\d/g, '')
    if (!vowels.has(base)) continue
    const stress = tokens[index].match(/[12]/)?.[0]
    if (stress) {
      markers.set(stressStart(tokens, index, previousVowelIndex),
        stress === '1' ? 'ˈ' : 'ˌ')
    }
    previousVowelIndex = index
  }

  const result = tokens.map((token, index) => {
    const base = token.replace(/\d/g, '')
    const stress = token.match(/\d/)?.[0]
    let sound = ipa[base] ?? base.toLowerCase()
    if (base === 'AH' && stress === '0') sound = 'ə'
    if (base === 'ER' && stress === '0') sound = 'ɚ'
    return `${markers.get(index) ?? ''}${sound}`
  }).join('')

  return `/${result}/`
}

function toAsciiEscapes(value) {
  return Array.from(value, (character) => {
    const codePoint = character.codePointAt(0)
    if (codePoint >= 0x20 && codePoint <= 0x7e) return character
    return `\\u${codePoint.toString(16).padStart(4, '0')}`
  }).join('')
}

const pronunciations = new Map(Object.entries(dictionary)
  .filter(([word]) => !/\(\d+\)$/.test(word))
  .filter(([word]) => /^[a-z][a-z'.-]*$/.test(word))
  .map(([word, pronunciation]) => [word, toAsciiEscapes(toIpa(pronunciation))]))

function cleanTranslation(value) {
  return tify(value
    .split(/\\n|\n/)
    .map((line) => line.trim())
    .filter((line) => line && !line.startsWith('[网络]'))
    .slice(0, 4)
    .join('；')
    .replaceAll('\t', ' '))
}

const translations = new Map()
const require = createRequire(import.meta.url)
const ecdictCsv = join(dirname(require.resolve('ecdict/package.json')), 'assets/ecdict.csv')
const parser = createReadStream(ecdictCsv).pipe(parse({
  columns: true,
  bom: true,
  relax_quotes: true,
  relax_column_count: true,
}))

for await (const record of parser) {
  const word = String(record.word ?? '').toLowerCase()
  if (!pronunciations.has(word) || translations.has(word)) continue
  const translation = cleanTranslation(String(record.translation ?? ''))
  if (translation) translations.set(word, toAsciiEscapes(translation))
}

const rows = Array.from(pronunciations, ([word, phonetic]) =>
  `${word}\t${phonetic}\t${translations.get(word) ?? ''}`)
  .sort((a, b) => a.localeCompare(b))

const compressed = gzipSync(Buffer.from(`${rows.join('\n')}\n`), { level: 9 })
for (const file of readdirSync('assets')) {
  if (file.startsWith('offline_dictionary.tsv.gz.part')) rmSync(join('assets', file))
}
const chunkSize = 440000
for (let offset = 0, index = 0; offset < compressed.length; offset += chunkSize, index++) {
  writeFileSync(
    `assets/offline_dictionary.tsv.gz.part${index}`,
    compressed.subarray(offset, offset + chunkSize),
  )
}
console.log(
  `Generated ${rows.length} pronunciations, ${translations.size} translations, ` +
  `${compressed.length} compressed bytes.`,
)
